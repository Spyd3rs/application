#!/usr/bin/env python
import requests
import sys
inp = sys.argv[1]
r = requests.get('http://192.168.0.89:9090/dataextractor/services/rest/extract/'+inp)
print(r.text)
payload = r.text
t = requests.put('http://192.168.0.66:9200/hackathon_hotel_location_2/location/'+inp,data=payload)
print(t.url)
