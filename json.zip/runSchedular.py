import os

f = open('/home/grijesh/json/json.txt')
for line in iter(f):
    print line
    os.system("python /home/grijesh/json/scheular.py "+line)
f.close()
