grep -o -h 'g[0-9]*-d[0-9]*' *.json >> /home/grijesh/json/json.txt
