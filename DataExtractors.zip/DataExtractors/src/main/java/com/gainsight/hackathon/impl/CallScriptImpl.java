package com.gainsight.hackathon.impl;



import com.gainsight.hackathon.contract.CallScripts;

import java.io.BufferedInputStream;
import java.util.LinkedList;
import java.util.List;

public class CallScriptImpl implements CallScripts {

	private static final String path ="C:\\Users\\U6018424\\Desktop\\html2text-master\\html2text-master\\";

	public String callScript(String script, String... id) {
		ProcessBuilder scriptBuilder = null;
		BufferedInputStream bin = null;
		Process process = null;
		String response = "";

		try {
			/*String path = this.getPopulateProperties().getScriptPath();*/
			byte[] by = new byte[1024];
			
			List<String> commands = new LinkedList<String>();
			commands.add("python");
			commands.add(path+script);
			for(String input : id)
				commands.add(input);
			System.out.println(commands.toString());
			String[] pythonCommand = commands.toArray(new String[0]);
			
			scriptBuilder = new ProcessBuilder(pythonCommand);
			process = scriptBuilder.start();
			bin = (BufferedInputStream) process.getInputStream();
			int i = 0;
			while ((i = bin.read(by)) != -1) {
				String tempResult = new String(by, 0, i);
				response = response + tempResult;
			}
			process.destroy();
			bin.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}


	

}
