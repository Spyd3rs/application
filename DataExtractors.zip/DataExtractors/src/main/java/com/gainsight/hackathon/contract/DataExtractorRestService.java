package com.gainsight.hackathon.contract;

import javax.ws.rs.*;

/**
 * Created by U6018424 on 4/11/2015.
 */

@Consumes("application/json")
public interface DataExtractorRestService {

    @GET
    @Path("/extract/details/{hotelId}")
    @Produces("application/json")
    public String getHotelDetails(@PathParam(value = "hotelId") String hotelId);

    @GET
    @Path("/extract/{hotelId}")
    @Produces("application/json")
    public String getLatLong(@PathParam(value = "hotelId") String hotelId);

}
