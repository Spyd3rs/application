package com.gainsight.hackathon.contract;

public interface CallScripts {

	public String callScript(String script, String... id);
	
}
