package com.gainsight.hackathon.impl;

import com.gainsight.hackathon.contract.CallScripts;
import com.gainsight.hackathon.contract.DataExtractorRestService;
import org.json.simple.parser.ParseException;

import java.util.Scanner;

/**
 * Created by U6018424 on 4/11/2015.
 */
public class DataExtractorImpl implements DataExtractorRestService {

    private static final String URL = "http://www.tripadvisor.in/";

    @Override
    public String getHotelDetails(String hotelId) {
        CallScripts callScripts = new CallScriptImpl();
        String response = callScripts.callScript("html2text.py",URL+hotelId);
        return response;
    }

    @Override
    public String getLatLong(String hotelId) {
        try {
            String response = getHotelDetails(hotelId);
            String latLong = null;
            Scanner scanner = new Scanner(response);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.startsWith("Address")) {
                    System.out.println(line);
                    String[] addressArray = line.split(":");
                    try {
                        latLong = new LatitudeLongitutdeUtils().getLatAndLong(addressArray[1]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            scanner.close();
            return latLong;
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        return  null;
    }
}
