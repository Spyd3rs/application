package com.gainsight.hackathon.test;

import com.gainsight.hackathon.contract.DataExtractorRestService;
import com.gainsight.hackathon.impl.DataExtractorImpl;
import org.junit.Test;

/**
 * Created by U6018424 on 4/11/2015.
 */
public class TestHotelDetails {

    @Test
    public void testExtractDetails()
    {
        DataExtractorRestService restService = new DataExtractorImpl();

        System.out.println(restService.getHotelDetails("g31310-d74739"));
    }

}
