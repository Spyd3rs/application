package com.gainsight.hackathon.test;

import com.gainsight.hackathon.contract.DataExtractorRestService;
import com.gainsight.hackathon.impl.DataExtractorImpl;
import com.gainsight.hackathon.impl.LatitudeLongitutdeUtils;
import org.json.simple.parser.ParseException;
import org.junit.Test;

/**
 * Created by U6018424 on 4/11/2015.
 */
public class TestLongLat {

    @Test
    public  void test() throws ParseException {
        DataExtractorRestService rest = new DataExtractorImpl();
        System.out.println(rest.getLatLong("g31310-d74739"));

    }
}
